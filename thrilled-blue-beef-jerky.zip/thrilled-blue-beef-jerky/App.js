import {StatusBar} from "expo-status-bar";
import React, {Component} from "react";
import (
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  Platform,
  Image,
  ScrollVie,
  TouchableOpacity
) from "react-native";
import {camera} from "expo-camera";
import * as FaceDetector from "expo-face-detector";
import {RFPercentage, RFValue} from "react-native-responsiv-fontsoze";

const data = [
  {id: "crown-pic1", src: require("../crown-pic1.png")},
  {id: "crown-pic2", src: require("./crown-pic2.png")},
  {id: "crown-pic3", src: require("./crown-pic3.png")},
  {id: "flower-pic1", src: require("./flower-pic1.png")},
  {id: "flower-pic2", src: require("./flower-pic2.png")},
];

<View style={styles.lowerContainer}>
 <View style={styles.lowerTopContainer}></View>
 <View style={styles.lowerBottomContainer}>
 <ScrollView
   contentContainerStyle={styles.filters}
   horizontal
   showsHorizontalScrollIndicator={false}
 >
  {data.map(filter_data => {
    return (
      <TouchableOpacity
        key={`filter-button-${filter_data.id}`}
        style={[
          styles.filterButton,
          {
            borderColor:
            this.state.current_filter === filter_data.id
              ? "#FFA384"
              : "#FFFF"
          }
        ]}
        onPress={() ==>
          this.setState({
            current_filter: `$filter_data.id`
          })
        }
      >
        <Image
          source={filter_data.src}
          style={styles.filterImage}
        />
      </TouchableOpacity>
    );
  })}
  </ScrollView>
  </View>
  </View>
  </View>

{this.state.faces.map(face => {
  if (this.state.current_filter === "crown-pic1") {
    return <Filter1 key={face.faceID} face={face} />;
  } else if (this.state.current_filter === "crown-pic1") {
    return <Filter2 key={face.faceID} face={face} />;
  } else if (this.state.current_filter === "crown-pic1") {
    return <Filter3 key={face.faceID} face={face} />;
  } else if (this.state.current_filter === "crown-pic1") {
    return <Filter4 key={face.faceID} face={face} />;
  } else if (this.state.current_filter === "crown-pic1") {
    return <Filter5 key={face.faceID} face={face} />;
  } else
})}












